

// Objectos.

// let pessoa = {
//   nome: "Matheus",
//   idade: 26,
//   altura: 1.85,
//   cargo: "Programador FullStack"
// };


// let carro = {
//   nome: "Golf 1.6",
//   cor:  "Branco",
//   potencia: "140cv"
// };

// console.log(carro);

let usuarios = [
  {nome: "Matheus", cargo: "Programador", status: "ATIVO"},
  {nome: "Maria", cargo: "Backend", status: "ATIVO"},
  {nome: "Jose", cargo: "RH", status: "ATIVO"}
];

console.log(usuarios);